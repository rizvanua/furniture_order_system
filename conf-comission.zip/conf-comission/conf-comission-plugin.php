<?php

/*
Plugin Name: Custom Registration
*/
function conf_form(){
	$role=wp_get_current_user()->roles;
	$role=implode("|",$role);
	echo $role;



// reCAPTCHA supported 40+ languages listed here: https://developers.google.com/recaptcha/docs/language
$lang = 'uk';
	
	
	echo '<form class="wpcf7-form" name="conf-form" id="conf-form" action="wp-content/plugins/conf-comission/conf-comission-form.php" method="post" novalidate="novalidate">

<div class="row" style="width:100%; clear:both">
	<span class="form-wrap date-473 third">
	<label class="required">
	Дата скарги:
	</label>
	<input  class="wpcf7-form-control wpcf7-date wpcf7-validates-as-required wpcf7-validates-as-date form-control" type="text" name="date" id="datepicker" value="">
	</span>
	<span class="form-wrap text-421 seventh">
	<label class="required" style="margin-left:20px; width:95.19808%;">
	Повне найменування юридичної особи - заявника скарги:
	</label>
	<input class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required form-control" type="text" style="margin-left:20px; width:95.19808%;" name="ur-name" size="40" value="" />
	</span>
</div>
<div class="row" style="width:100%; clear:both">
	<span class="form-wrap text-427 seventh">
		<label class="required">
		ПІБ Керівника заявника:
		</label>
		<input class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required form-control" type="text" name="pib-head" size="40" value="" />
	</span>
	<span class="form-wrap text-433 third">
		<label class="required" style="margin-left:20px; width:88.79552%;">
		ЄДРПОУ заявника:
		</label>
		<input class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required form-control" type="text" name="edrpou" style="margin-left:20px; width:88.79552%;" size="40" maxlength="8" value="" />
	</span>
</div>
<div class="row" style="width:100%; clear:both">
	<span class="form-wrap text-823 whole">
		<label class="required">Юридична адреса заявника:</label>
		<input class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required form-control" type="text" name="adress" size="40" value="" />
	</span>
</div>
<div class="row" style="width:100%; clear:both">	
	<span class="form-wrap menu-91">
		<label class="required">
		Найменування філії, щодо дій якої спрямовується скарга:
		</label>
		<select class="wpcf7-form-control wpcf7-select wpcf7-validates-as-required form-control" name="branch-name"><option value="">оберіть філію</option><option value="ПАТ ">ПАТ "Укргазвидобування"</option><option value="ГПУ ">ГПУ "Шебелинкагазвидобування"</option><option value="ГПУ ">ГПУ "Полтавагазвидобування"</option><option value="ГПУ ">ГПУ "Львівгазвидобування"</option><option value="Управління з переробки газу та газового конденсату;">Управління з переробки газу та газового конденсату;</option><option value="УБМР">УБМР</option><option value="Укргазспецбудмонтаж">Укргазспецбудмонтаж</option><option value="БУ ">БУ "Укргбургаз"</option><option value="ГУ ">ГУ "Укргазпромгеофізика"</option><option value="УкрНДІгаз">УкрНДІгаз</option><option value="ЛІКВО">ЛІКВО</option><option value="УОК ">УОК "Червона Рута"</option></select>
	</span>
</div>
<div class="row" style="width:100%; clear:both">
	<span class="form-wrap menu-474 whole">
		<label class="required">Підстава для скарги:</label>
		<select class="wpcf7-form-control wpcf7-select wpcf7-validates-as-required form-control" name="complain-reason" id="test"><option value="">оберіть підставу</option><option value="скарга по процесу кваліфікації Контрагентів">скарга по процесу кваліфікації Контрагентів</option><option value="скарга щодо процесу вибору Контрагентів">скарга щодо процесу вибору Контрагентів</option><option value="скарга Контрагентів з питань їх дискваліфікації (внесення до Реєстру)">скарга Контрагентів з питань їх дискваліфікації (внесення до Реєстру)</option></select>		
		<span class="arrow"></span>
	</span>
</div>
<div class="row" style="width:100%; clear:both">
	<span class="form-wrap textarea-270 half-width">
		<label>Пропозиції Заявника:</label>
		<textarea class="wpcf7-form-control wpcf7-textarea form-control" cols="40" name="offer" style="margin-right:10px; width:96.6386554621849%" rows="10"></textarea>
	</span>
	<span class="form-wrap textarea-271 half-width">
		<label>Список документів, що додаються:</label>
		<textarea class="wpcf7-form-control wpcf7-textarea form-control" cols="40" name="doc-list" style="margin-left:10px; width:96.6386554621849%" rows="10"></textarea>
	</span>
</div>
<div class="row" style="width:100%; clear:both">
	<span class="form-wrap textarea-272 half-width">
		<label>ПІБ, посада особи, що підписала скаргу:</label>
		<textarea class="wpcf7-form-control wpcf7-textarea form-control" cols="40" name="person-name" style="margin-right:10px; width:96.6386554621849%" rows="10"></textarea>
	</span>
	<span class="form-wrap textarea-273 half-width">
		<label>Контактні дані для зв\'язку з Заявником:</label>
		<textarea class="wpcf7-form-control wpcf7-textarea form-control" cols="40" name="contacts" style="margin-left:10px; width:96.6386554621849%" rows="10"></textarea>
	</span>
</div>
<div class="row" style="width:100%; clear:both">
	<span class="form-wrap half-width">
		<label>Файлы:</label>
		<input type="file" id="getFile" name="" multiple="multiple" accept=".txt,image/*">
	<div class="ajax-respond"></div>
	</span>
	<span class="form-wrap half-width">
		<label class="required">Ваш @-мейл:</label>
		<input type="email" name="email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email form-control" aria-required="true" aria-invalid="false">
	</span>
</div>
<div class="row" style="width:100%; clear:both">
	<span class="form-wrap checkbox half-width style-blue">
		<p class="required">Вся внесена інформація вірна?</p>
		<label>
			<input type="checkbox" name="check">
			<span class="checkbox-material">
				<span class="check"></span>
			</span>
			Так, вірна
		</label>
	</span>
	<span class="form-wrap half-width">	
		<div class="g-recaptcha" style="width:100%;margin-top: 20px" data-sitekey="6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI"></div>
		<div id="captcha-alert" style="display:none">Будь ласка підтвердіть, що ви не є робот</div>
	</span>
</div>';
if($role==='administrator')
echo '
<div class="row" style="width:100%; clear:both">
	<span class="form-wrap radio style-blue" style="width:33.33%;float:left">
		<label>
			<input type="radio" name="status" value="2">
			<span class="circle"></span>
			<span class="check"></span>
			Задовільнити
		</label>	
	</span>
	<span class="form-wrap radio style-blue" style="width:33.33%;float:left">
		<label>
			<input type="radio" name="status" value="1">
			<span class="circle"></span>
			<span class="check"></span>
			Відхилити
		</label>	
	</span>
	<span class="form-wrap radio style-blue" style="width:33.33%; float:left">
		<label>
			<input type="radio" name="status" value="0">
			<span class="circle"></span>
			<span class="check"></span>
			В обробку
		</label>	
	</span>	
</div>
';

echo '<div class="row" style="width:100%; height:50px; clear:both; display:flex; justify-content:center">
<button id="submitConf" type="submit">Надісдати</button>
</div>	
</form>
<script type="text/javascript" >
	/*jQuery(document).ready(function($) {
		//Календарь	
		$( function() {
			$( "#datepicker" ).datepicker();
		} );
			// Переменная куда будут располагаться данные файлов
	 
			var files;
			 
			// Вешаем функцию на событие
			// Получим данные файлов и добавим их в переменную
			 
			$("input[type=file]").change(function(){
				files = this.files;
				console.log(files);
			});
			$("#conf-form").submit(function(e){
				e.preventDefault();	
					var formURL = $(this).attr("action");
					var postData = $(this).serializeArray();
					
					 $.ajax(
					{
						url : formURL,
						type: "POST",
						data : postData,
						success:function(data, textStatus, jqXHR) 
						{
							//data: return data from server
							console.log(data);
							if(data==="Error1"){
								console.log("Просю заполнить капчу")
								$("#captcha-alert").show();
							}
						},
						error: function(jqXHR, textStatus, errorThrown) 
						{
							//if fails      
						}
					});	
				
			});
	});*/
	</script>
';

}
// Register a new shortcode: [cr_custom_registration]
add_shortcode( 'cr_custom_registration', 'custom_registration_shortcode' );
  
// The callback function that will replace [book]
function custom_registration_shortcode() {   
    return conf_form();
}

?>