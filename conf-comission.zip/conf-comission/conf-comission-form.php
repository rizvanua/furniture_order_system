<?php
header('Content-type: text/html; charset=UTF-8');
require_once ($_SERVER['DOCUMENT_ROOT'].'\wp-content\themes\twentyten\recaptcha_keys.php');
require_once (__DIR__ .'/autoload.php');
include_once ($_SERVER['DOCUMENT_ROOT'].'/wp-config.php');
global $wpdb;
session_start ();
$CONNECT = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
/*echo json_encode($wpdb->users);
if ($CONNECT) echo'OK';
else echo 'EROOR';*/
/*echo json_encode($_POST);*/

	// If the form submission includes the "g-captcha-response" field
	// Create an instance of the service using your secret
	$recaptcha = new \ReCaptcha\ReCaptcha($secret);
	// Make the call to verify the response and also pass the user's IP address
    $resp = $recaptcha->verify($_POST['g-recaptcha-response'], $_SERVER['REMOTE_ADDR']);
	if ($resp->isSuccess()){
		if (isset($_POST['date']) && isset($_POST['ur-name']) && isset($_POST['pib-head'])&& isset($_POST['edrpou'])&& isset($_POST['branch-name'])&& isset($_POST['complain-reason'])&& isset($_POST['email'])&& isset($_POST['check'])&&isset($_POST['g-recaptcha-response'])){
			$data = $_POST;
			$time= $_POST['date'];
			$urname=esc_html($_POST['ur-name']);
			$pibhead=esc_html($_POST['pib-head']);
			$edrpou=$_POST['edrpou'];
			$adress=esc_html($_POST['adress']);
			$branchname=esc_html($_POST['branch-name']);
			$complainreason=esc_html($_POST['complain-reason']);
			$offer=esc_html($_POST['offer']);
			$doclist=esc_html($_POST['doc-list']);
			$personname=esc_html($_POST['person-name']);
			$contacts=esc_html($_POST['contacts']);
			$email=sanitize_email($_POST['email']);
			$status=intval($_POST['status']);
			/*UTF-8*/
			/*function convert_utf_8($mydata){
				return html_entity_decode(preg_replace("/U\+([0-9A-F]{4})/", "&#x\\1;", $mydata), ENT_NOQUOTES, 'UTF-8');
			}
			$time= $_POST['date'];
			$urname=convert_utf_8($_POST['ur-name']);
			$pibhead=convert_utf_8($_POST['pib-head']);
			$edrpou=$_POST['edrpou'];
			$adress=convert_utf_8($_POST['adress']);
			$branchname=convert_utf_8($_POST['branch-name']);
			$complainreason=convert_utf_8($_POST['complain-reason']);
			$offer=convert_utf_8($_POST['offer']);
			$doclist=convert_utf_8($_POST['doc-list']);
			$personname=convert_utf_8($_POST['person-name']);
			$contacts=convert_utf_8($_POST['contacts']);
			$email=$_POST['email'];
			$status=$_POST['status'];*/
			/**/
			/*Validation*/
			$urname=esc_html($urname);
			$pibhead=esc_html($pibhead);
			$edrpou=intval($edrpou);
			$adress=esc_html($adress);
			$branchname=esc_html($branchname);
			$complainreason=esc_html($complainreason);
			$offer=esc_html($offer);
			$doclist=esc_html($doclist);
			$personname=esc_html($personname);
			$contacts=esc_html($contacts);
			$email=sanitize_email($email);
			$status=intval($status);			
			/**/
			echo strlen($email);
			/*Upload Files on the Sefver*/
			if((strlen($email)>0)){
				if( isset( $_FILES[0] ) ){
					$files = array();
					
					  $uploaddir = './uploads/'.$email.'/'; // . - текущая папка где находится submit.php
					   if( ! is_dir( $uploaddir ) ) mkdir( $uploaddir, 0777 );
					   // переместим файлы из временной директории в указанную
					   foreach( $_FILES as $file ){
						    $_filesname   = iconv("UTF-8", "windows-1251",$file['name']);							
							if( move_uploaded_file( $file['tmp_name'], $uploaddir . basename($_filesname) ) ){
								$files[] = realpath( $uploaddir . $_filesname );
							}
							else{
								$error = true;
							}
						}
										/*echo json_encode($_FILES);*/
										
					
					echo strlen($email);
				}
				/**/
				/*$wpdb->query($wpdb->prepare( 
							"
							 INSERT INTO conf_commission(time,urname,pibhead,edrpou,adress,branchname,complainreason,offer,doclist,personname,contacts,email,status)
							 VALUES ($time,$urname,$pibhead,$edrpou,$adress,$branchname,$complainreason,$offer,$doclist,$personname,$contacts,$email,$status);
							" 
							));*/
				/**/
				/**/
				/*$myresalt=$wpdb->get_results("SELECT urname FROM conf_commission  WHERE id = 1");
				echo json_encode($myresalt);*/
				/**/
				/*WP Insert*/
				$myinsert=$wpdb->query($wpdb->prepare(
				"
				INSERT INTO conf_commission
				(time,urname,pibhead,edrpou,adress,branchname,complainreason,offer,doclist,personname,contacts,email)
				VALUES (%s,%s,%s,%d,%s,%s,%s,%s,%s,%s,%s,%s)
				",
				$time,$urname,$pibhead,$edrpou,$adress,$branchname,$complainreason,$offer,$doclist,$personname,$contacts,$email				
				));
					/*$myinsert=$wpdb->insert( 
						'conf_commission', 
						array( 
							'time' => $time,
							'urname' => $urname,
							'pibhead' => $pibhead,
							'edrpou' => $edrpou,
							'adress' => $adress,
							'branchname' => $branchname,
							'complainreason' => $complainreason,
							'offer' => $offer,
							'doclist' => $doclist,
							'personname' => $personname,
							'contacts' => $contacts,
							'email' => $email								
						)
					);*/
					$fileList=scandir('./uploads/'.$email.'/');
					echo json_encode($myinsert);
					/**/
				/*$utf8string = html_entity_decode(preg_replace("/U\+([0-9A-F]{4})/", "&#x\\1;", $string), ENT_NOQUOTES, 'UTF-8');

				$json = array(
					"Sample" => array(
						"context" => $string
					)
				);

				$encoded = json_encode($json);
				var_dump($encoded);

				$unescaped = preg_replace_callback('/\\\u(\w{4})/', function ($matches) {
					return html_entity_decode('&#x' . $matches[1] . ';', ENT_COMPAT, 'UTF-8');
				}, $encoded);
				var_dump($unescaped);*/
				// If the form submission includes the "g-captcha-response" field
			// Create an instance of the service using your secret
			/*$recaptcha = new \ReCaptcha\ReCaptcha($secret);
			// Make the call to verify the response and also pass the user's IP address
				$resp = $recaptcha->verify($_POST['g-recaptcha-response'], $_SERVER['REMOTE_ADDR']);
				if ($resp->isSuccess()){
				echo "SAY YES";
				}*/
				/*echo $utf8string;	*/
				/*echo json_encode( $data );*/
			}
			else{
				echo 'Error3';
			}
		}
		else {
			echo 'Not Complite';			
		}
		
	}
	else{
		echo 'Error1';
	}	
?>